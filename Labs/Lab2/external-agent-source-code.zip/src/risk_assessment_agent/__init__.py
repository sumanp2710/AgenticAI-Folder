from .tools import web_search

TOOLS = [web_search]
